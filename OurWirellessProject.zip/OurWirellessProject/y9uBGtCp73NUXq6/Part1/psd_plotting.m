function psd_plotting(input1,input2,input3)

end