function chan=Rayleigh_fading_channel(SampleRate,PathDelays,AveragePathGains,MaximumDopplerShift,ChannelFiltering,NumSamples,FadingTechnique)
%%
%%
%Parameter Initial

end