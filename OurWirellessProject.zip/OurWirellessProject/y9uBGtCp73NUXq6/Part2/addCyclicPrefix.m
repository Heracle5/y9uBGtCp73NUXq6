
%% function to add cyclic prefix
% CP should only work if longer than channel impulse response


function [input_signal_cp, length_cp] = addCyclicPrefix(input_signal,prefix_length)
    
    N = length(input_signal); % Length of input signal
    L = prefix_length; 
  
    cyclic_prefix = input_signal(N-L+1:N);  % last samples of input signal as the CP
    input_signal_cp  = [cyclic_prefix; input_signal];  % prepend signal with CP
    length_cp = L;  % for the case where the cp length is automatic

end